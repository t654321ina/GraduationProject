package com.wangjie.rapidfloatingactionbutton.listener;

import com.wangjie.rapidfloatingactionbutton.rfabgroup.RapidFloatingActionButtonGroup;

/**
 * Author: wangjie
 * Email: tiantian.china.2@gmail.com
 * Date: 5/5/15.
 */
public interface OnRapidFloatingButtonGroupListener {
    void onRFABGPrepared(RapidFloatingActionButtonGroup rapidFloatingActionButtonGroup);
}
